import os
import time
from datetime import datetime
from bs4 import BeautifulSoup
from fpdf import FPDF
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

# -------------------------------------------------------------------
# Fixed working URL (New Delhi District Court)
# -------------------------------------------------------------------
COURT_URL = "https://newdelhi.dcourts.gov.in/cause-list-%e2%81%84-daily-board/"

# -------------------------------------------------------------------
# PDF Helper Class
# -------------------------------------------------------------------
class PDF(FPDF):
    def header(self):
        self.set_font("Arial", "B", 14)
        self.cell(0, 10, self.title, ln=True, align="C")
        self.ln(5)

# -------------------------------------------------------------------
# Save each judge’s cause list into a separate PDF
# -------------------------------------------------------------------
def save_judge_pdf(judge_name, table_data, date_str):
    pdf = PDF()
    pdf.title = f"{judge_name} - Cause List ({date_str})"
    pdf.add_page()

    if not table_data:
        pdf.set_font("Arial", "", 11)
        pdf.cell(0, 10, "No case data found.", ln=True)
    else:
        headers = list(table_data[0].keys())
        col_widths = [190 // max(1, len(headers))] * len(headers)

        pdf.set_font("Arial", "B", 10)
        for h, w in zip(headers, col_widths):
            pdf.cell(w, 8, h[:25], border=1, align="C")
        pdf.ln()

        pdf.set_font("Arial", "", 9)
        for row in table_data:
            for (key, val), w in zip(row.items(), col_widths):
                safe_text = str(val).replace("–", "-").replace("—", "-")
                pdf.cell(w, 8, safe_text[:30], border=1)
            pdf.ln()

    os.makedirs("data", exist_ok=True)
    filename = f"{judge_name.replace(' ', '_')}_{date_str}.pdf"
    path = os.path.join("data", filename)
    pdf.output(path)
    return path

# -------------------------------------------------------------------
# Fetch HTML and click calendar date
# -------------------------------------------------------------------
def fetch_cause_list_html(selected_date):
    """Open site, click selected date in calendar, return updated HTML."""
    chrome_options = Options()
    chrome_options.add_argument("--disable-gpu")
    chrome_options.add_argument("--no-sandbox")
    # Remove comment below to see browser actions for debugging
    # chrome_options.add_argument("--headless")
    chrome_options.add_argument("--log-level=3")

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    driver.get(COURT_URL)
    time.sleep(5)  # wait for calendar to load

    target_day = int(selected_date.strftime("%d"))

    try:
        date_cells = driver.find_elements(By.TAG_NAME, "td")
        clicked = False
        for cell in date_cells:
            if cell.text.strip() == str(target_day):
                driver.execute_script("arguments[0].scrollIntoView(true);", cell)
                cell.click()
                time.sleep(8)
                clicked = True
                break
        if not clicked:
            print(f"⚠️ Could not find date {target_day} on calendar. It may not be available.")
    except Exception as e:
        print("⚠️ Error clicking date:", e)

    html = driver.page_source
    driver.quit()
    return html

# -------------------------------------------------------------------
# Parse all judge sections and extract tables
# -------------------------------------------------------------------
def parse_judge_sections(html, date_str):
    soup = BeautifulSoup(html, "html.parser")
    sections = soup.find_all("div", class_="elementor-widget-container")

    pdf_files = []
    judge_counter = 0

    for section in sections:
        text = section.get_text(" ", strip=True)
        # Identify judge section
        if "In The Court" in text or "In the Court" in text:
            judge_name = text.split("Court Of")[-1].strip()[:60]

            # Look for tables following this section
            next_tables = section.find_all_next("table")
            for table in next_tables:
                headers = [th.get_text(strip=True) for th in table.find_all("th")]
                if not headers:
                    continue
                rows = table.find_all("tr")[1:]
                table_data = []
                for tr in rows:
                    cells = [td.get_text(" ", strip=True) for td in tr.find_all("td")]
                    if len(cells) == len(headers):
                        table_data.append(dict(zip(headers, cells)))

                if table_data:
                    pdf_path = save_judge_pdf(judge_name, table_data, date_str)
                    pdf_files.append(pdf_path)
                    judge_counter += 1
                    print(f"✅ Saved PDF for {judge_name}")
                break  # Stop after the first table for each judge

    return pdf_files, judge_counter

# -------------------------------------------------------------------
# Main Function
# -------------------------------------------------------------------
def scrape_and_save_pdf(selected_date: datetime, district: str = "New Delhi"):
    """Scrape cause list for all judges for the selected date."""
    print(f"🚀 Fetching data for {selected_date.strftime('%d-%m-%Y')}...")

    html = fetch_cause_list_html(selected_date)

    if not html.strip():
        return None, "⚠️ Unable to fetch the cause list page."

    date_str = selected_date.strftime("%d-%m-%Y")
    pdf_files, count = parse_judge_sections(html, date_str)

    if count == 0:
        return None, "⚠️ No judge cause lists found on the website. Try another date."

    return "data", f"✅ {count} judge-wise cause lists saved successfully in the 'data' folder."
