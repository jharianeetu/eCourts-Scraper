import streamlit as st
from datetime import date, datetime
from scraper import scrape_and_save_pdf

st.set_page_config(page_title="New Delhi - Per Judge PDFs")
st.title("eCourts Scraper")

st.markdown(
    "Court complex is selected automatically. Choose a date and click the button to generate **one PDF per judge**."
)

# Date selector
selected_date = st.date_input("Select Cause List Date", value=date.today())

#  Fetch button
if st.button("Download PDFs"):
    st.info("Generating per-judge PDFs...")
    try:
        pdf_path, msg = scrape_and_save_pdf(
            datetime(selected_date.year, selected_date.month, selected_date.day)
        )
        if pdf_path:
            st.success(msg)
            with open(pdf_path, "rb") as f:
                st.download_button("📥 Download Summary PDF", f, file_name=pdf_path.split("/")[-1])
        else:
            st.warning(msg)
    except Exception as e:
        st.error(f"❌ Error: {e}")
